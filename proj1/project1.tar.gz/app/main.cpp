#include <iostream>
#include "proj1.hpp"


int main()
{
    return 0;
}
